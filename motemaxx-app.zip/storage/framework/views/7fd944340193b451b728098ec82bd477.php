<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="flex flex-col">
                        <div class="rounded shadow-lg m-4 p-4 flex justify-between items-center">
                            <div>
                                <div class="text-xl font-bold p-4">
                                    Motivations
                                </div>
                                <div>
                                    <a href="<?php echo e(route('motivation.index')); ?>" class="block p-4">
                                        Voir la liste
                                    </a>
                                </div>
                            </div>
                            <div class="text-xl font-bold p-4">
                                <?php echo e($motivations); ?>

                            </div>
                        </div>
                        <div class="rounded shadow-lg m-4 p-4 flex justify-between items-center">
                            <div>
                                <div class="text-xl font-bold p-4">
                                    Reservations
                                </div>
                                <div>
                                    <a href="<?php echo e(route('reservation.index')); ?>" class="block p-4">
                                        Voir la liste
                                    </a>
                                </div>
                            </div>
                            <div class="text-xl font-bold p-4">
                                <?php echo e($reservations); ?>

                            </div>
                        </div>
                        <div class="rounded shadow-lg m-4 p-4 flex justify-between items-center">
                            <div>
                                <div class="text-xl font-bold p-4">
                                    Services
                                </div>
                                <div>
                                    <a href="<?php echo e(route('prestation.index')); ?>" class="block p-4">
                                        Voir la liste
                                    </a>
                                </div>
                            </div>
                            <div class="text-xl font-bold p-4">
                                <?php echo e($services); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\vibecro\motemaxx-app\resources\views/admin/index.blade.php ENDPATH**/ ?>