

<img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="motemaxx" <?php echo $attributes->merge(['class' => 'h-20']); ?>><?php /**PATH C:\xampp\htdocs\vibecro\motemaxx-app\resources\views/components/application-logo.blade.php ENDPATH**/ ?>