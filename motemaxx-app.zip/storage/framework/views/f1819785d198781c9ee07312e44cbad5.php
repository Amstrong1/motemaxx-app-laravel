<input <?php echo $attributes->merge([
    'class' => implode(' ', [
        $errors->has($name) ? 'form-input is-invalid block w-full placeholder:text-sm' : 'form-input block w-full placeholder:text-sm'
    ]), 
]); ?>>
<?php /**PATH C:\xampp\htdocs\vibecro\motemaxx-app\resources\views/components/inputs/text.blade.php ENDPATH**/ ?>