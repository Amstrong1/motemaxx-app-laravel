

<input type="date" <?php echo $attributes->merge([
    'class' => implode(' ', [
        $errors->has($name) ? 'form-input is-invalid block w-full placeholder:italic' : 'form-input block w-full placeholder:italic'
    ]), 
]); ?>><?php /**PATH C:\xampp\htdocs\vibecro\motemaxx-app\resources\views/components/inputs/date.blade.php ENDPATH**/ ?>