<select {{$attributes->merge(['class'=>"simple-select form-input"])}} multiple>
    {{$slot}}
</select>